
public class Bicycle {

}
